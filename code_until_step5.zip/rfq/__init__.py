"""Ridgeline RFQ inbox parser."""
